# 📜 Gestion et déploiement des stratégies de groupe (GPO)

> Durcissement et standardisation des postes du parc RAID-A-PORTER via des stratégies de groupe Active Directory.

## Statut

🚧 **Chantier planifié** — identifié explicitement comme perspective à moyen terme du projet : "déploiement de stratégies de groupe (GPO) avancées : durcissement des postes, restrictions logicielles, déploiement applicatif." Non encore mis en œuvre au moment de la rédaction.

## Objectifs visés

- **Durcissement des postes** : désactivation de services inutiles, politique de verrouillage d'écran, restrictions USB
- **Restrictions logicielles** : contrôle des exécutables autorisés (AppLocker ou équivalent)
- **Déploiement applicatif** : installation automatisée de logiciels via GPO sur les postes `Ordinateur - W11` du parc

## Point de départ

L'annuaire est déjà structuré en OU par service métier avec groupes `_R`/`_M`/`_G` (voir `ad-structuration-annuaire`), ce qui offre un périmètre d'application naturel pour des GPO différenciées par service (ex. restrictions plus strictes pour un poste Finance que pour un poste Technique).

## Prochaines étapes

- [ ] Définir une baseline de durcissement (CIS Benchmark ou équivalent) adaptée au contexte homelab
- [ ] Créer les GPO par OU service, en cohérence avec la structuration existante
- [ ] Tester le déploiement sur un sous-ensemble de postes avant généralisation
- [ ] Documenter chaque GPO et son objectif

## Repos liés

- `ad-structuration-annuaire`
- `ad-automatisation-powershell`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
