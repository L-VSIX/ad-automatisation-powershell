# 🏗️ Conception de l'infrastructure — Découverte des composants du datacenter

> Choix et dimensionnement des hyperviseurs Proxmox VE constituant le socle du homelab RAID-A-PORTER.

## Contexte

Sur du matériel hétérogène de récupération, l'objectif était de reproduire l'organisation d'un mini-datacenter d'entreprise : séparation fonctionnelle claire des rôles entre hôtes, plutôt qu'un unique gros serveur mutualisant tout.

## Inventaire des hyperviseurs

| Hôte | Ressources | Rôle principal | Charge hébergée |
|---|---|---|---|
| ESXi MSI | 4 vCPU / 8 Go / 2×1 To HDD | Cœur de réseau | OPNsense + DHCP, PBS |
| ESXi HPP | 4 vCPU / 16 Go / 1 To HDD + 1 To SSD + 250 Go SSD | Services principaux | AD, Wazuh, Zabbix, GLPI, Tailscale |
| ESXi ACE (LENOVO) | 4 vCPU / 8 Go / 1 To HDD + 1 To SSD + 500 Go SSD | Services de fichiers | 2 VM Filer DFS Windows Server 25 |
| ESXi LENOVO (PRA) | 2 vCPU / 6 Go / 1 To HDD | Plan de reprise | Proxmox Backup Server secondaire |
| ESXi ASUS | 6 vCPU / 24 Go / 500 Go SSD | Poste de gestion | VMware Workstation, postes W11 |
| Raspberry Pi 3 | 1 vCPU / 1 Go / 100 Go HDD | Accès distant | Nœud Tailscale + point d'accès Wi-Fi |

## Logique de conception

- **Isolation des rôles critiques** : le nœud portant le pare-feu (MSI) est dédié au cœur de réseau, pour ne jamais dépendre d'un autre hôte au démarrage.
- **Séparation sauvegarde primaire / PRA** : deux instances Proxmox Backup Server sur deux hôtes physiquement distincts.
- **Stockage à 3 niveaux** par nœud : disque système (PVE), volume VM applicatives, volume stockage/sauvegarde.

## Indicateurs clés

| Indicateur | Valeur |
|---|---|
| Hyperviseurs Proxmox en production | 4 |
| Hyperviseurs Proxmox Backup Server | 2 |
| Services déployés (VM + LXC) | ≈ 20 |
| VLAN actifs | 6 |

## Repos liés

- `proxmox-gestion-ressources-hotes` — déploiement et administration
- `opnsense-segmentation-vlan` — réseau
- `pbs-plan-de-reprise-pra` — sauvegarde et PRA

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
