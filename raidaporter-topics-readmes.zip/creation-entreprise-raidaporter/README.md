# 🏢 Création de l'entreprise fictive RAID-A-PORTER

> Point de départ du homelab : la définition d'un cas d'usage d'entreprise réaliste pour donner du sens à chaque choix technique.

## Objectif

Avant de poser la moindre VM, ce projet a démarré par la modélisation d'une **PME fictive** : RAID-A-PORTER, ~60 collaborateurs répartis sur 6 services métier (Direction Générale, Finance, Commerce, Technique, Ressources Humaines, Logistique, Informatique).

Cette étape de "worldbuilding" n'est pas cosmétique : elle conditionne toute l'architecture qui suit — plan d'adressage, structuration de l'annuaire Active Directory, arborescence des partages fichiers, périmètre de la supervision.

## Périmètre défini

- **Nom de domaine** : `raidaporter.local`
- **Organigramme** : 1 direction générale + 5 directions opérationnelles + 1 DSI
- **Effectif cible** : ~60 utilisateurs provisionnés dans l'annuaire
- **Vocation** : pédagogique et démonstrative — simuler les décisions et arbitrages d'une vraie DSI

## Pourquoi cette approche

Construire un homelab "en vrac" (une VM par techno testée isolément) apprend des outils sans contexte. Partir d'un cas d'entreprise oblige à faire les mêmes arbitrages qu'en environnement réel : segmentation réseau, conventions de nommage, gouvernance des droits, priorisation des mises en production par service métier.

## Ce qui en découle

Ce scénario d'entreprise irrigue l'ensemble des autres dépôts du projet : infrastructure et virtualisation, segmentation réseau par VLAN, annuaire Active Directory structuré par service, stratégie de sauvegarde, supervision/sécurité, applicatifs métier.

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
