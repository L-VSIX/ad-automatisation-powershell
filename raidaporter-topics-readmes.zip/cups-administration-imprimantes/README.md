# 🖨️ Administration d'imprimantes physiques et virtuelles — CUPS

> Service d'impression centralisé du homelab, gérant à la fois du matériel physique et des files d'attente virtuelles (PDF, Scan to Folder).

## Statut

🚧 **Documentation à compléter** — CUPS fait partie du socle d'outils collaboratifs prévu pour le homelab ; le déploiement détaillé et la configuration des files d'impression restent à formaliser dans ce dépôt.

## Objectif

Reproduire, à l'échelle du homelab, le service d'impression d'une PME : files d'attente partagées par service métier, gestion centralisée des pilotes, et impression virtuelle (génération de PDF) pour les postes n'ayant pas besoin d'imprimante physique.

## Ce qui reste à documenter

- [ ] Déploiement du serveur CUPS (conteneur LXC ou VM dédiée)
- [ ] Ajout et partage des imprimantes physiques du parc
- [ ] Configuration d'une imprimante virtuelle PDF pour les tests sans matériel
- [ ] Intégration avec l'authentification Active Directory pour le contrôle d'accès aux files par service

## Repos liés

- `cups-scan-to-folder` — fonctionnalité complémentaire
- `ad-structuration-annuaire` — contrôle d'accès prévu

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
