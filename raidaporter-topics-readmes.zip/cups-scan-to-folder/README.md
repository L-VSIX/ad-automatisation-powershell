# 📄 Mise en place d'une solution « Scan to Folder » — CUPS

> Numérisation directe vers les dossiers partagés DFS des services métier, sans passer par un poste intermédiaire.

## Statut

🚧 **Documentation à compléter** — fonctionnalité complémentaire à `cups-administration-imprimantes`, s'appuyant sur l'architecture DFS déjà en place. Procédure détaillée à formaliser dans ce dépôt.

## Objectif

Permettre à un multifonction (physique ou simulé) de déposer directement un document numérisé dans le dossier partagé du service métier concerné — `\\raidaporter.local\<service>` — plutôt que de transiter par un poste utilisateur.

## Point d'appui existant

L'arborescence de partage DFS respecte déjà l'organigramme RAID-A-PORTER, avec un dossier racine par service et des ACL NTFS alignées sur les groupes `_R`/`_M`/`_G` (voir `dfs-architecture`). La solution Scan to Folder doit s'appuyer sur cette structure existante plutôt que créer un dépôt de numérisation séparé.

## Ce qui reste à documenter

- [ ] Configuration du protocole de dépôt (SMB direct ou FTP/SFTP intermédiaire selon le matériel)
- [ ] Compte de service dédié avec droits d'écriture limités aux dossiers cibles
- [ ] Convention de nommage des fichiers numérisés
- [ ] Test de bout en bout : numérisation → dépôt → visibilité côté utilisateur du service

## Repos liés

- `cups-administration-imprimantes`
- `dfs-architecture`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
