# 🔑 Automatisation de la gestion des habilitations avec PowerShell — Serveur de fichiers

> Provisioning automatique des répertoires de service et application des permissions NTFS, en cohérence directe avec les scripts de gestion des comptes AD.

## Principe

Les scripts PowerShell d'industrialisation développés pour l'Active Directory (voir `ad-automatisation-powershell`) couvrent également le volet fichiers : à la création ou à la réaffectation d'un utilisateur, le script crée le répertoire associé sur le serveur de fichiers et applique les permissions NTFS correspondant aux groupes `_R`/`_M`/`_G` du service concerné.

## Ce que couvre l'automatisation

- Création du répertoire personnel/service sur le filer DFS approprié
- Application des ACL NTFS héritées des groupes de sécurité AD
- Réaffectation des permissions lors d'un changement de service d'un utilisateur (retrait des droits sur l'ancien service, attribution sur le nouveau)

## Pourquoi automatiser cette étape en particulier

C'est le point où les erreurs manuelles ont le plus d'impact en termes de sécurité : un dossier créé sans ACL correcte, ou une permission non retirée lors d'un changement de service, expose potentiellement des données à des utilisateurs qui ne devraient pas y avoir accès. L'automatisation garantit que la création du compte AD, du répertoire et des droits se fait toujours dans le même mouvement, sans étape oubliée.

## Repos liés

- `ad-automatisation-powershell` — scripts source
- `dfs-architecture` — arborescence cible

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
