# 🔔 Intégration des notifications GLPI avec Mattermost

> Objectif : notifier en temps réel l'ouverture ou la mise à jour d'un ticket GLPI dans un canal Mattermost dédié au support.

## Statut

🚧 **Chantier planifié** — dépend du déploiement de Mattermost (`mattermost-canaux-communication`), pas encore mis en œuvre.

## Principe visé

GLPI dispose d'un système de notifications configurable par événement (création de ticket, changement de statut, ajout de suivi). L'objectif est d'ajouter une notification sortante de type webhook, pointant vers l'API Incoming Webhook de Mattermost, dans le canal `#glpi-tickets`.

## Complémentarité avec les tickets créés par Zabbix

Cette intégration prend tout son sens combinée à `zabbix-tickets-glpi` : une alerte de supervision crée un ticket GLPI, qui lui-même notifie immédiatement l'équipe support sur Mattermost — bouclant la chaîne détection → ticket → notification sans intervention manuelle.

## Prochaines étapes

- [ ] Déployer Mattermost et créer le canal `#glpi-tickets`
- [ ] Configurer la notification webhook côté GLPI
- [ ] Définir les événements déclencheurs (création, changement de priorité, clôture)
- [ ] Tester la chaîne complète avec `zabbix-tickets-glpi`

## Repos liés

- `glpi-support-helpdesk`
- `zabbix-tickets-glpi`
- `mattermost-canaux-communication`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
