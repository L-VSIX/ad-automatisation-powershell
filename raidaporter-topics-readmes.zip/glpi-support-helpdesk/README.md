# 🎫 Administration du support Helpdesk — GLPI

> Gestion de parc et suivi du support technique pour les ~60 utilisateurs de RAID-A-PORTER, avec inventaire automatisé et authentification unifiée AD.

## Déploiement

GLPI est installé sur une VM Debian dédiée. L'inscription des actifs se fait de deux façons :

- **automatiquement** via l'agent GLPI installé sur les serveurs
- **manuellement** pour les équipements ne pouvant pas exécuter l'agent (imprimantes, équipements réseau)

## Structuration retenue

L'entité racine a été renommée en **« homelab »**, avec trois sous-entités structurant l'inventaire : `Test`, `Utilisateurs`, `IT`. Plusieurs localisations récursives ont été déclarées pour permettre le rattachement géographique des actifs.

## Authentification unifiée (LDAPS)

Le rattachement de GLPI à l'Active Directory permet l'authentification unique des utilisateurs et l'import des comptes. Cette intégration nécessite l'installation du certificat de l'autorité de certification du domaine.

> ⚠️ Sans ce certificat, la connexion LDAPS **échoue silencieusement** — pas de message d'erreur explicite, ce qui rend le diagnostic plus long si on ne pense pas immédiatement au certificat.

## Volet Helpdesk

GLPI centralise le suivi des tickets support pour l'ensemble du parc, avec un lien à venir vers la supervision Zabbix (création automatique de tickets, voir `zabbix-tickets-glpi`) et vers la prise en main à distance (voir `guacamole-helpdesk`).

## Repos liés

- `ad-structuration-annuaire` — source d'authentification
- `zabbix-tickets-glpi`
- `glpi-notifications-mattermost`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
