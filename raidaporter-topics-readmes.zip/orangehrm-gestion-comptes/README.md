# 👥 Gestion et administration des comptes utilisateurs — OrangeHRM

> SIRH (système d'information RH) du homelab, retenu après un essai infructueux d'une alternative, avec intégration LDAP contre l'annuaire raidaporter.local.

## Choix de la solution

OrangeHRM a été retenu après un essai de **FrappeHRM**, jugé trop complexe à configurer hors d'un environnement Docker déjà maîtrisé. Le déploiement Docker d'OrangeHRM a suivi la procédure habituelle du homelab.

## Intégration LDAP — la difficulté rencontrée

La liaison LDAP vers l'annuaire `raidaporter.local` nécessitait l'import du certificat de l'autorité de certification du domaine — **pas dans la VM hôte, mais directement dans le conteneur Docker** :

```bash
# Copie du certificat dans le bind-mount du conteneur
cp /usr/local/share/ca-certificates/raidaporter-H-WINSERV-2-CA.crt \
   /home/lilou/docker/orangehrm/ldap/

# Volumes ajoutés au docker-compose.yml
# - ./ldap/ldap.conf:/etc/ldap/ldap.conf
# - ./ldap/...CA.crt:/usr/local/share/ca-certificates/...CA.crt

docker compose up -d --force-recreate orangehrm
docker exec orangehrm update-ca-certificates
```

Sans cet import, le bind LDAPS échoue **silencieusement**, sans message d'erreur explicite côté interface — piège classique de ce type d'intégration.

## Gestion des comptes utilisateurs

Une fois l'authentification LDAP fonctionnelle, la gestion des comptes RH s'appuie sur l'annuaire AD existant (voir `ad-structuration-annuaire`) plutôt que sur une base de comptes dupliquée — cohérent avec l'organigramme RAID-A-PORTER (6 services métier).

## Repos liés

- `ad-structuration-annuaire` — annuaire source
- `guacamole-helpdesk` — autre applicatif intégré à l'AD

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
