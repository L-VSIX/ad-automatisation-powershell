# 🔁 Élaboration d'un plan de reprise d'activité (PRA)

> Deuxième site de sauvegarde Proxmox Backup Server dédié à la reprise d'activité, physiquement et logiquement distinct du site de production.

## Principe

Une seconde instance **Proxmox Backup Server** est déployée dans un LXC sur un hyperviseur dédié (ESXi LENOVO, VLAN PRA), constituant un second dépôt de sauvegardes indépendant du site principal.

## Choix technologique

Avant d'adopter PBS pour le PRA, un simple partage de dossier mutualisé avait été évalué comme cible de réplication des sauvegardes — jugé inadapté : pas de déduplication, pas de gestion fine de la rétention, pas de vérification d'intégrité native.

## Validation de la portabilité

Test réalisé : snapshot d'un conteneur LXC puis redéploiement sur un autre nœud Proxmox à partir de ce snapshot — preuve de concept validant qu'une charge peut être restaurée sur un hôte différent de l'hôte d'origine, condition nécessaire à un scénario de reprise crédible.

## Isolation réseau

Le PRA dispose de son propre VLAN dédié (`VLAN 50 — PRA`), filtré indépendamment du reste de l'infrastructure, pour limiter l'impact d'un incident de sécurité sur le site de production vers le site de secours.

## État d'avancement

- [x] Second hôte PBS opérationnel
- [x] Test de portabilité (snapshot + redéploiement inter-nœuds) validé
- [ ] Playbook de restauration end-to-end documenté et testé pour chaque service critique
- [ ] Scénario complet de PCA/PRA formalisé

## Repos liés

- `pbs-strategie-sauvegarde` — politique de sauvegarde du site principal
- `conception-infrastructure-datacenter` — hôte PRA dédié
- `opnsense-segmentation-vlan` — VLAN PRA

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
