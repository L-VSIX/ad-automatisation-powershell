# 💾 Mise en œuvre de la stratégie de sauvegarde

> Politique de sauvegarde à deux niveaux : image des VM/LXC via Proxmox Backup Server, fichiers des postes via UrBackup.

## Proxmox Backup Server (PBS)

Choisi pour trois raisons : **déduplication efficace**, gestion fine de la rétention, intégration native à Proxmox VE (sauvegarde/restauration en un clic depuis l'interface).

> 💡 **Spécificité clé** : PBS ne sauvegarde que la capacité **réellement occupée** d'un disque virtuel, pas sa taille déclarée. Un disque de 500 Go utilisé à 60 Go ne consomme que 60 Go côté dépôt — l'empreinte de stockage réelle est donc bien inférieure à une sauvegarde "pleine" classique.

## UrBackup — sauvegarde fichier

Installée sur la VM `h-winserv-2`, avec un disque dédié de 500 Go. Cible principalement les **postes de travail** et quelques serveurs, en complément de la sauvegarde image PBS — deux granularités différentes (fichier vs image système complète) pour deux besoins de restauration différents.

L'agent client s'installe via un script auto-généré par le serveur UrBackup, ce qui simplifie le déploiement de masse sur le parc de postes.

## Répartition des rôles

| Solution | Granularité | Cible | Fréquence typique |
|---|---|---|---|
| Proxmox Backup Server | Image complète (VM/LXC) | Toutes les charges virtualisées | Planifiée, rétention gérée |
| UrBackup | Fichier | Postes de travail + serveurs sélectionnés | Sauvegarde incrémentale |

## Repos liés

- `pbs-plan-de-reprise-pra` — second site de sauvegarde
- `zabbix-dashboard-supervision` — supervision des jobs de sauvegarde

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
