# 🔀 Administration de commutateurs virtuels — Proxmox

> Configuration du bridge réseau `vmbr0` en mode VLAN aware pour porter la segmentation à 6 VLAN sur les hyperviseurs Proxmox.

## Principe

Chaque nœud Proxmox dispose d'un commutateur virtuel Linux Bridge (`vmbr0`) reliant l'interface physique aux VM/LXC hébergés. Pour porter plusieurs VLAN sur un seul lien physique, l'option **VLAN aware** est activée sur ce bridge.

## Procédure

1. Activer *VLAN aware* sur l'interface physique `vmbr0` (Datacenter › Système réseau).
2. Pour chaque VLAN métier, créer une interface logique dédiée (Linux Bond ou Linux VLAN) avec l'IP de passerelle et le tag correspondant.
3. Sur chaque VM ou conteneur LXC, attacher la carte réseau virtuelle à `vmbr0` en renseignant simplement le **tag VLAN** voulu — pas besoin de bridge dédié par VLAN.

## Bénéfice de l'approche

Un seul commutateur virtuel par nœud suffit à porter l'ensemble des 6 VLAN de l'infrastructure (LAN, TEST, SRV, GES, SEC, PRA, VPN), le tagging 802.1Q se faisant au niveau de chaque interface de VM/LXC plutôt que par la multiplication de bridges physiques.

## Repos liés

- `opnsense-segmentation-vlan` — cartographie complète des VLAN
- `hyperv-commutateurs-virtuels` — approche équivalente sous Hyper-V

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
