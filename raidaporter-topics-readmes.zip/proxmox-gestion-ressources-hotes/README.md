# ⚙️ Gestion des ressources systèmes et déploiement des hôtes — Proxmox

> Homogénéisation et exploitation du parc d'hyperviseurs Proxmox VE, y compris l'expérience — et le retour en arrière — sur le clustering.

## Homogénéisation des nœuds

Convention de dimensionnement retenue pour le stockage de chaque nœud : **300 Go PVE** (système) + **600 Go serveur** (VM applicatives) + **1 To stockage** (bureautique/sauvegarde), afin de garder une organisation cohérente d'un hyperviseur à l'autre malgré du matériel hétérogène.

## Cluster Proxmox : essai puis démantèlement assumé

Les nœuds MSI, HPP et ACE ont d'abord été regroupés en cluster pour permettre migration et clonage inter-nœuds. Le mécanisme de quorum a posé un problème concret : le nœud MSI héberge le pare-feu (cœur de réseau) et doit pouvoir démarrer **seul**, ce que le quorum interdit sans contournement :

```bash
pvecm expected 1
```

Cette contrainte étant incompatible avec une exploitation réelle, le cluster a été démantelé :

```bash
systemctl stop pve-cluster corosync
pmxcfs -l
rm /etc/corosync/*
rm /etc/pve/corosync.conf
killall pmxcfs
systemctl start pve-cluster
```

> 💡 **Retour d'expérience** : la haute disponibilité "sur le papier" n'est pas toujours le bon choix opérationnel. Ici, l'autonomie de démarrage du nœud cœur de réseau primait sur la commodité de migration à chaud offerte par le cluster.

## Montage de stockage additionnel (NAS)

```bash
# Sur l'hyperviseur, puis partagé à un LXC
mkdir -p /mnt/nas-test
mount -t cifs -o user=lilou //192.168.1.51/NAS-hard /mnt/nas-test
pct set 114 -mp0 /mnt/nas-test,mp=/mnt/nas-test-smb

# Ou directement en virtiofs côté VM (plus performant, persistant)
mkdir -p /mnt/nas-test-smb
sudo mount -t virtiofs nas-test /mnt/nas-test-smb
```

## Difficultés rencontrées

| Difficulté | Cause | Résolution |
|---|---|---|
| Démarrage du cœur de réseau bloqué | Quorum Proxmox exigeant plusieurs nœuds | Démantèlement du cluster, hyperviseurs autonomes |
| VM Windows ne démarre plus après modification CPU | Type de CPU incompatible avec l'OS invité | Restauration snapshot, ajustement progressif |

## Repos liés

- `conception-infrastructure-datacenter`
- `pbs-strategie-sauvegarde`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
