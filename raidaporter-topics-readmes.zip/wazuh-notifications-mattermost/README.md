# 🔔 Intégration des notifications Wazuh avec Mattermost

> Objectif : faire remonter les alertes de sécurité Wazuh vers un canal Mattermost dédié, pour un traitement en quasi temps réel par l'équipe SOC.

## Statut

🚧 **Chantier planifié** — dépend du déploiement de Mattermost (`mattermost-canaux-communication`), pas encore mis en œuvre.

## Principe visé

Wazuh permet de configurer des **intégrations sortantes** (module `integrator`) capables d'appeler un webhook externe en fonction du niveau de règle déclenché. L'objectif est de router les alertes de sévérité élevée vers l'API Incoming Webhook de Mattermost, dans un canal `#soc-wazuh` distinct du canal de supervision générale.

## Différenciation avec les notifications Zabbix

Contrairement aux alertes Zabbix (disponibilité/performance), les alertes Wazuh sont des **événements de sécurité** (tentative d'intrusion, modification suspecte de fichier, échec d'authentification répété). Elles justifient un canal et un circuit d'escalade distincts, avec une astreinte potentiellement différente.

## Prochaines étapes

- [ ] Déployer Mattermost et créer le canal `#soc-wazuh`
- [ ] Configurer le module `integrator` côté manager Wazuh
- [ ] Définir le seuil de niveau de règle déclenchant la notification
- [ ] Documenter la procédure de traitement d'une alerte reçue

## Repos liés

- `wazuh-soc`
- `mattermost-canaux-communication`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
