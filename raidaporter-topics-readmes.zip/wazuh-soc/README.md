# 🛡️ Conception d'un centre des opérations de sécurité (SOC) — Wazuh

> Wazuh comme brique de détection d'intrusion et fondation d'un SOC pédagogique pour le homelab RAID-A-PORTER.

## Déploiement

Wazuh a d'abord été installé sur Ubuntu Server, puis **migré sur un conteneur LXC** afin de bénéficier de l'intégration Active Directory via winbind pour l'authentification des équipes SOC.

## Inscription des agents

L'inscription se fait par téléchargement du paquet adapté à l'architecture cible :

```bash
# Identifier l'architecture
which rpm    # ou which dpkg → famille de paquet
uname -m     # x86_64 → amd64 | aarch64 → arm64

# Installation type Debian/Ubuntu
wget https://packages.wazuh.com/4.x/apt/pool/main/w/wazuh-agent/wazuh-agent_4.10.3-1_amd64.deb \
  && sudo WAZUH_MANAGER='192.168.1.22' WAZUH_AGENT_NAME='<nom>' \
     dpkg -i ./wazuh-agent_4.10.3-1_amd64.deb

sudo systemctl daemon-reload
sudo systemctl enable wazuh-agent
sudo systemctl start wazuh-agent
```

## Incident résolu — enrôlement des agents

Le port **1515** (enrollment) doit être ouvert en complément du port **1514** (données) sur le pare-feu inter-VLAN. Sans cette règle, l'agent échoue silencieusement à s'enregistrer auprès du manager. Incident identifié lors du basculement des hôtes vers les VLAN segmentés.

## Vision SOC pédagogique

L'ambition à moyen terme dépasse la simple détection d'intrusion par hôte : centraliser les logs de l'ensemble de l'infrastructure (pare-feu, AD, applicatifs) dans un puits de logs unique exploité par Wazuh, pour se rapprocher d'un véritable centre d'opérations de sécurité.

## État d'avancement

- [x] Manager Wazuh opérationnel en LXC
- [x] Agents déployés sur les hôtes Linux principaux
- [ ] Puits de logs centralisé couvrant pare-feu + AD + applicatifs
- [ ] Règles de corrélation et tableaux de bord SOC dédiés

## Repos liés

- `opnsense-segmentation-vlan` — règle de filtrage 1514/1515
- `wazuh-notifications-mattermost`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
