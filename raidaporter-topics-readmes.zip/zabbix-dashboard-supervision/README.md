# 📊 Conception d'un tableau de bord de supervision — Zabbix

> Zabbix 7 comme point central de supervision de l'ensemble des serveurs Linux applicatifs du homelab.

## Déploiement

Serveur Zabbix 7 installé sur une VM Debian 12. Chaque serveur Linux applicatif y est rattaché via l'agent `zabbix-agent`.

```bash
sudo apt install zabbix-agent -y
sudo nano /etc/zabbix/zabbix_agentd.conf
# Server=192.168.1.22
# ServerActive=192.168.1.22
# Hostname=<nom_du_serveur>
sudo systemctl restart zabbix-agent
sudo systemctl enable zabbix-agent
```

## Déclaration d'un hôte côté interface

Chaque hôte supervisé nécessite trois éléments :

1. Un **modèle** (ex. *Linux by Zabbix Agent*) qui définit les items et triggers standards.
2. Un **groupe d'hôtes** (ex. *Linux servers*) pour organiser les tableaux de bord.
3. Une **interface agent** renseignant l'adresse IP de la machine supervisée.

## Construction du tableau de bord

Le tableau de bord central agrège l'état de santé de l'ensemble du parc supervisé : disponibilité, charge CPU/RAM, espace disque, et alertes actives sur les services critiques (contrôleurs de domaine, filers DFS, pare-feu).

## État d'avancement

- [x] Serveur Zabbix opérationnel, agents déployés sur les serveurs Linux
- [ ] Tableaux de bord orientés métier (par service RAID-A-PORTER plutôt que par techno)
- [ ] Seuils d'alerte affinés par criticité de service

## Repos liés

- `zabbix-notifications-mattermost` — remontée d'alertes
- `zabbix-tickets-glpi` — création automatique de tickets

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
