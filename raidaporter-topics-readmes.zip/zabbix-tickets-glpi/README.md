# 🎫 Création automatique de tickets dans GLPI depuis Zabbix

> Objectif : transformer une alerte critique Zabbix en ticket GLPI, pour relier supervision technique et suivi du support côté DSI.

## Statut

🚧 **Chantier planifié** — s'appuie sur les deux briques déjà opérationnelles (`zabbix-dashboard-supervision` et `glpi-support-helpdesk`) mais l'intégration entre les deux n'est pas encore mise en œuvre.

## Principe visé

GLPI expose une API REST permettant la création programmatique de tickets. L'approche envisagée est un média **Webhook** côté Zabbix, déclenché sur les triggers de sévérité élevée, appelant l'API GLPI pour ouvrir un ticket avec le contexte de l'alerte (hôte, service, description du trigger).

## Pourquoi cette intégration

Dans une DSI réelle, une alerte de supervision non traitée à temps se perd. La faire atterrir directement dans l'outil de ticketing (déjà utilisé pour la gestion de parc) garantit une traçabilité et un suivi, sans dépendre de la vigilance humaine sur un tableau de bord.

## Prochaines étapes

- [ ] Générer un token d'API applicative côté GLPI
- [ ] Créer le média Webhook Zabbix ciblant l'endpoint GLPI `Ticket`
- [ ] Mapper la sévérité Zabbix vers la priorité du ticket GLPI
- [ ] Tester la boucle complète : déclenchement alerte → ticket → résolution → clôture

## Repos liés

- `zabbix-dashboard-supervision`
- `glpi-support-helpdesk`

## Auteur

**Lilian Vertueux** — [LinkedIn](https://www.linkedin.com/in/lilian-vertueux/)
